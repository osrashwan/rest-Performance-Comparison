package org.boi.enquiry.security.rest;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.boi.enquiry.security.domain.CcRCustomerEntity;
import org.boi.enquiry.security.domain.CustomerEntity;
import org.boi.enquiry.security.service.CcRCustomerService;
import org.boi.enquiry.security.service.CustomerService;

@Path("/ccRCustomers")
@Named
public class CcRCustomerResource implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private CcRCustomerService ccRCustomerService;
    
    /**
     * Get the complete list of CcRCustomer Entries <br/>
     * HTTP Method: GET <br/>
     * Example URL: /ccRCustomers
     * @return List of CcRCustomerEntity (JSON)
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<CcRCustomerEntity> getAllCcRCustomers() {
        return ccRCustomerService.findAllCcRCustomerEntities();
    }
    
    /**
     * Get the number of CcRCustomer Entries <br/>
     * HTTP Method: GET <br/>
     * Example URL: /ccRCustomers/count
     * @return Number of CcRCustomerEntity
     */
    @GET
    @Path("count")
    @Produces(MediaType.APPLICATION_JSON)
    public long getCount() {
        return ccRCustomerService.countAllEntries();
    }
    
    /**
     * Get a CcRCustomer Entity <br/>
     * HTTP Method: GET <br/>
     * Example URL: /ccRCustomers/3
     * @param id
     * @return A CcRCustomer Entity (JSON)
     */
    @Path("{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public CcRCustomerEntity getCcRCustomerById(@PathParam("id") Long id) {
        return ccRCustomerService.find(id);
    }
    
    /**
     * Create a CcRCustomer Entity <br/>
     * HTTP Method: POST <br/>
     * POST Request Body: New CcRCustomerEntity (JSON) <br/>
     * Example URL: /ccRCustomers
     * @param ccRCustomer
     * @return A CcRCustomerEntity (JSON)
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public CcRCustomerEntity addCcRCustomer(CcRCustomerEntity ccRCustomer) {
        return ccRCustomerService.save(ccRCustomer);
    }
    
    /**
     * Update an existing CcRCustomer Entity <br/>
     * HTTP Method: PUT <br/>
     * PUT Request Body: Updated CcRCustomerEntity (JSON) <br/>
     * Example URL: /ccRCustomers
     * @param ccRCustomer
     * @return A CcRCustomerEntity (JSON)
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public CcRCustomerEntity updateCcRCustomer(CcRCustomerEntity ccRCustomer) {
        return ccRCustomerService.update(ccRCustomer);
    }
    
    /**
     * Delete an existing CcRCustomer Entity <br/>
     * HTTP Method: DELETE <br/>
     * Example URL: /ccRCustomers/3
     * @param id
     */
    @Path("{id}")
    @DELETE
    public void deleteCcRCustomer(@PathParam("id") Long id) {
        CcRCustomerEntity ccRCustomer = ccRCustomerService.find(id);
        ccRCustomerService.delete(ccRCustomer);
    }
    
}
