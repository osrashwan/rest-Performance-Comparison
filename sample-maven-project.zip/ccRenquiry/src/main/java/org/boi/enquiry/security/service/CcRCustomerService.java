package org.boi.enquiry.security.service;

import java.io.Serializable;
import java.util.List;

import javax.inject.Named;
import javax.transaction.Transactional;

import org.boi.enquiry.security.domain.CcRCustomerEntity;
import org.boi.enquiry.security.service.security.SecurityWrapper;

@Named
public class CcRCustomerService extends BaseService<CcRCustomerEntity> implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public CcRCustomerService(){
        super(CcRCustomerEntity.class);
    }
    
    @Transactional
    public List<CcRCustomerEntity> findAllCcRCustomerEntities() {
        
        return entityManager.createQuery("SELECT o FROM CcRCustomer o ", CcRCustomerEntity.class).getResultList();
    }
    
    @Override
    @Transactional
    public long countAllEntries() {
        return entityManager.createQuery("SELECT COUNT(o) FROM CcRCustomer o", Long.class).getSingleResult();
    }
    
    @Override
    @Transactional
    public CcRCustomerEntity save(CcRCustomerEntity ccRCustomer) {
        String username = SecurityWrapper.getUsername();
        
        ccRCustomer.updateAuditInformation(username);
        
        return super.save(ccRCustomer);
    }
    
    @Override
    @Transactional
    public CcRCustomerEntity update(CcRCustomerEntity ccRCustomer) {
        String username = SecurityWrapper.getUsername();
        ccRCustomer.updateAuditInformation(username);
        return super.update(ccRCustomer);
    }
    
    @Override
    protected void handleDependenciesBeforeDelete(CcRCustomerEntity ccRCustomer) {

        /* This is called before a CcRCustomer is deleted. Place here all the
           steps to cut dependencies to other entities */
        
    }

}
