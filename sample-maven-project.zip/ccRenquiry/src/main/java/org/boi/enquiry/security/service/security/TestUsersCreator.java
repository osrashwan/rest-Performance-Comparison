package org.boi.enquiry.security.service.security;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.boi.enquiry.security.domain.security.UserEntity;
import org.boi.enquiry.security.domain.security.UserRole;
import org.boi.enquiry.security.domain.security.UserStatus;

/**
 * Creates some test users in fresh database.
 * 
 * TODO This class is temporary for test, only. Just delete this class
 * if you do not need the test users to be created automatically.
 *
 */
@Singleton
@Startup
public class TestUsersCreator {

    private static final Logger logger = Logger.getLogger(TestUsersCreator.class.getName());
    
    @Inject
    private UserService userService;
    
    @PostConstruct
    public void postConstruct() {
        
       if(userService.countAllEntries() == 0) {
           
            logger.log(Level.WARNING, "Creating test user 'admin' with password 'admin'.");
            UserEntity admin = new UserEntity();
            admin.setUsername("admin");
            admin.setPassword("admin");
            admin.setRoles(Arrays.asList(new UserRole[]{UserRole.Administrator}));
            admin.setStatus(UserStatus.Active);
            admin.setEmail("admin@domain.test");
            
            userService.save(admin);
            
            logger.log(Level.WARNING, "Creating test user 'registered' with password 'registered'.");
            UserEntity registeredUser = new UserEntity();
            registeredUser.setUsername("registered");
            registeredUser.setPassword("registered");
            registeredUser.setRoles(Arrays.asList(new UserRole[]{UserRole.Registered}));
            registeredUser.setStatus(UserStatus.Active);
            registeredUser.setEmail("registered@domain.test");
            
            userService.save(registeredUser);
            
            logger.log(Level.WARNING, "Creating test user 'ppSNVIEW' with password 'ppSNVIEW'.");
            UserEntity ppSNVIEWUser = new UserEntity();
            ppSNVIEWUser.setUsername("ppSNVIEW");
            ppSNVIEWUser.setPassword("ppSNVIEW");
            ppSNVIEWUser.setRoles(Arrays.asList(new UserRole[]{UserRole.ppSNVIEW}));
            ppSNVIEWUser.setStatus(UserStatus.Active);
            ppSNVIEWUser.setEmail("ppSNVIEW@domain.test");
            
            userService.save(ppSNVIEWUser);
            
            logger.log(Level.WARNING, "Creating test user 'ciSSEARCH' with password 'ciSSEARCH'.");
            UserEntity ciSSEARCHUser = new UserEntity();
            ciSSEARCHUser.setUsername("ciSSEARCH");
            ciSSEARCHUser.setPassword("ciSSEARCH");
            ciSSEARCHUser.setRoles(Arrays.asList(new UserRole[]{UserRole.ciSSEARCH}));
            ciSSEARCHUser.setStatus(UserStatus.Active);
            ciSSEARCHUser.setEmail("ciSSEARCH@domain.test");
            
            userService.save(ciSSEARCHUser);
            
            logger.log(Level.WARNING, "Creating test user 'apPLINK' with password 'apPLINK'.");
            UserEntity apPLINKUser = new UserEntity();
            apPLINKUser.setUsername("apPLINK");
            apPLINKUser.setPassword("apPLINK");
            apPLINKUser.setRoles(Arrays.asList(new UserRole[]{UserRole.apPLINK}));
            apPLINKUser.setStatus(UserStatus.Active);
            apPLINKUser.setEmail("apPLINK@domain.test");
            
            userService.save(apPLINKUser);
            
        }
    }
}
