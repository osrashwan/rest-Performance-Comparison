package org.boi.enquiry.security.domain.security;

/**
 * User account status
 * */
public enum UserStatus {

    Active, Disabled, NotConfirmed, RegistrationError
}
