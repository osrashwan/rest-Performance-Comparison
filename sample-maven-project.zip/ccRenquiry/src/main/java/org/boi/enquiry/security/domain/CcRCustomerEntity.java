package org.boi.enquiry.security.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity(name="CcRCustomer")
@Table(name="\"CCRCUSTOMER\"")
@XmlRootElement
public class CcRCustomerEntity extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name="\"accountNumber\"")
    @Digits(integer = 4, fraction = 0)
    private Integer accountNumber;

    @Column(name="\"nsC\"")
    @Digits(integer = 4, fraction = 0)
    private Integer nsC;

    @Size(max = 80)
    @Column(length = 80, name="\"forename\"")
    private String forename;

    @Size(max = 80)
    @Column(length = 80, name="\"surename\"")
    private String surename;

    @Column(name="\"doB\"")
    @Temporal(TemporalType.DATE)
    private Date doB;

    @Size(max = 15)
    @Column(length = 15, name="\"ppSN\"")
    private String ppSN;

    @Column(name = "ENTRY_CREATED_BY")
    private String createdBy;

    @Column(name = "ENTRY_CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "ENTRY_MODIFIED_BY")
    private String modifiedBy;

    @Column(name = "ENTRY_MODIFIED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;
    
    public Integer getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Integer getNsC() {
        return this.nsC;
    }

    public void setNsC(Integer nsC) {
        this.nsC = nsC;
    }

    public String getForename() {
        return this.forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getSurename() {
        return this.surename;
    }

    public void setSurename(String surename) {
        this.surename = surename;
    }

    public Date getDoB() {
        return this.doB;
    }

    public void setDoB(Date doB) {
        this.doB = doB;
    }

    public String getPpSN() {
        return this.ppSN;
    }

    public void setPpSN(String ppSN) {
        this.ppSN = ppSN;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getModifiedAt() {
        return modifiedAt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }
    
    public void updateAuditInformation(String username) {
        if (this.getId() != null) {
            modifiedAt = new Date();
            modifiedBy = username;
        } else {
            createdAt = new Date();
            modifiedAt = createdAt;
            createdBy = username;
            modifiedBy = createdBy;
        }
    }
    
}
