package org.boi.enquiry.security.domain.security;

/**
 * User role
 * */
public enum UserRole {

    Administrator, Registered, ppSNVIEW, ciSSEARCH, apPLINK;
}
